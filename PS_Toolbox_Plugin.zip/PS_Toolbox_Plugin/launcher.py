from .ui.Progress_ui import  Ui_ProgressMainWindow
from .ui.ps_toolbox_ui import Ui_PSToolbox
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
from qgis.core import QgsProject,NULL, QgsRasterLayer
from qgis.PyQt.QtCore import Qt, QRegExp, QDate, QFileInfo, QDir
# from .core import Export
import matplotlib.pyplot as plt
import re
import numpy as np
import os
import json
import pandas as pd
import sys
import subprocess


	
class mainWindow(QtWidgets.QDialog, Ui_PSToolbox):

	def __init__(self,  parent):
		super(mainWindow, self).__init__(parent.mainWindow())
		self.installation = False
		done = False
		
		if not os.path.exists(os.path.join(os.path.dirname(__file__),'.config')):
			done = self.setInstallationPath(first = True)
		
		with open(os.path.join(os.path.dirname(__file__),'.config'),'r') as f:
			line = f.readline()
			if 'bin_path' in line:
				self.exe = line.split('=')[-1].strip()
				if not os.path.exists(self.exe):
					reply = QtWidgets.QMessageBox.question(self, 'Installation Path', 'The selected Installation path does not exist, do you want to change it?',
						QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
					if reply == QtWidgets.QMessageBox.Yes:
						done = self.setInstallationPath()
						self.installation = True
				else:
					self.installation = True
					done = True

		if self.installation and done:
			self.setupUi(self)
			self.iface = parent
			self.Heatmap_button.clicked.connect(self.Heatmap)
			self.Interferometric_button.clicked.connect(self.Interferometric)
			self.Kmz_button.clicked.connect(self.KMZ)
			self.Filtering_button.clicked.connect(self.Filtering)
			self.Linear_button.clicked.connect(self.Linear)
			self.Vectorial_button.clicked.connect(self.Vectorial)
			self.Roads_Linear_button.clicked.connect(self.Roads_Linear)
						
					
			self.actionSet_Installation_Path.triggered.connect(self.setInstallationPath)
		else:
			self.close()
		

	def Heatmap(self):
		print("Heatmap")
		from .Heatmap.launcher import mainWindow
		from . import resources_rc
		# self.setVisible(False)
		self.close()
		dlg = mainWindow(self.iface)
		dlg.show()#exec_()
		dlg.exec_()

	def Interferometric(self):
		print("Interferometric Sections")
		from .Interferometric_Sections.launcher import mainWindow
		from . import resources_rc
		# self.setVisible(False)
		self.close()
		dlg = mainWindow(self.iface)
		dlg.show()#exec_()
		dlg.exec_()
	
	def KMZ(self):
		print("KMZ Export")
		from .KMZ_Export.launcher import mainWindow
		from . import resources_rc
		# self.setVisible(False)
		self.close()
		dlg = mainWindow(self.iface)
		dlg.show()#exec_()
		dlg.exec_()
	
	def Filtering(self):
		print("Filtering")
		from .Filtering.launcher import mainWindow
		from . import resources_rc
		# self.setVisible(False)
		self.close()
		dlg = mainWindow(self.iface)
		dlg.show()#exec_()
		dlg.exec_()

	def Linear(self):
		print("Linear Infrastructure")
		from .Linear_Infrastructure.LinearInfrastructures_plugin import LinearInfrastuctures_Plugin
		from . import resources_rc
		# self.setVisible(False)
		self.close()
		dlg = LinearInfrastuctures_Plugin(self.iface)
		dlg.run()
		# dlg = LinearInfrastuctures_Plugin(self.iface)
		# dlg.show()#exec_()
		# dlg.exec_()

	def Vectorial(self):
		print("Vectorial Decomposition")
		from .Vectorial_Decomposition.launcher import mainWindow
		from . import resources_rc
		# self.setVisible(False)
		self.close()
		dlg = mainWindow(self.iface)
		dlg.show()#exec_()
		dlg.exec_()


	def Roads_Linear(self):
		print("Roads Linear Infrastructure")
		from .Roads_Linear_Infrastructure.LinearInfrastructures_plugin import LinearInfrastuctures_Plugin
		from . import resources_rc
		# self.setVisible(False)
		self.close()
		dlg = LinearInfrastuctures_Plugin(self.iface)
		dlg.run()
		

			


	def setInstallationPath(self,first=False):
		done = False
		if first:
			reply = QtWidgets.QMessageBox.question(self, 'Installation Path', 'Installation Path not set, Set it now?',
        	QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
			if reply == QtWidgets.QMessageBox.Yes:
				direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File",filter="PS_toolbox*")
				if direct[0]:
					config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
					config.write(f"bin_path = {direct[0]}")
					done = True
		else:
			direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File",filter="PS_toolbox*")
			if direct[0]:
				config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
				config.write(f"bin_path = {direct[0]}")
				done = True

		return done


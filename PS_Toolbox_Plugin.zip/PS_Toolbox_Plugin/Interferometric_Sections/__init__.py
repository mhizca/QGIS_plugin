# -*- coding: utf-8 -*-
"""

/***************************************************************************
Name                : Interferometric Sections 
Date                : Jan 12, 2021
copyright           : (C) 2020 by Nhzca
email               : santiago.giraldo@sagima.com.co

 ***************************************************************************/

"""

def name():
	return "Interferometric Sections"


def author():
	return "Santiago Giraldo (NHAZCA)"

def authorName():
	return author()

def email():
	return "santiago.giraldo@sagima.com.co"

def icon():
	return "icons/logoInterferometric.png"

def version():
	return "1.0"

def qgisMinimumVersion():
	return "3.1"

def classFactory(iface):
	from .Interferometricsections_plugin import Interferometricsections_Plugin
	return Interferometricsections_Plugin(iface)
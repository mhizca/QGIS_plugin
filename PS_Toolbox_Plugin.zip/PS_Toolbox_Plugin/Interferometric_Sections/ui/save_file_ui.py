# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'save_file.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_save_file(object):
    def setupUi(self, save_file):
        save_file.setObjectName("save_file")
        save_file.resize(400, 300)
        self.groupBox = QtWidgets.QGroupBox(save_file)
        self.groupBox.setGeometry(QtCore.QRect(50, 20, 301, 80))
        self.groupBox.setObjectName("groupBox")
        self.csv_check = QtWidgets.QCheckBox(self.groupBox)
        self.csv_check.setGeometry(QtCore.QRect(40, 30, 70, 17))
        self.csv_check.setObjectName("csv_check")
        self.shp_check = QtWidgets.QCheckBox(self.groupBox)
        self.shp_check.setGeometry(QtCore.QRect(180, 30, 70, 17))
        self.shp_check.setObjectName("shp_check")
        self.groupBox_2 = QtWidgets.QGroupBox(save_file)
        self.groupBox_2.setGeometry(QtCore.QRect(50, 110, 301, 80))
        self.groupBox_2.setObjectName("groupBox_2")
        self.horizontalLayoutWidget = QtWidgets.QWidget(self.groupBox_2)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(9, 20, 291, 51))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.save_path_text = QtWidgets.QLineEdit(self.horizontalLayoutWidget)
        self.save_path_text.setObjectName("save_path_text")
        self.horizontalLayout.addWidget(self.save_path_text)
        self.save_path_button = QtWidgets.QPushButton(self.horizontalLayoutWidget)
        self.save_path_button.setObjectName("save_path_button")
        self.horizontalLayout.addWidget(self.save_path_button)
        self.dont_save_button = QtWidgets.QPushButton(save_file)
        self.dont_save_button.setGeometry(QtCore.QRect(50, 240, 75, 23))
        self.dont_save_button.setObjectName("dont_save_button")
        self.save_button = QtWidgets.QPushButton(save_file)
        self.save_button.setGeometry(QtCore.QRect(280, 240, 75, 23))
        self.save_button.setObjectName("save_button")

        self.retranslateUi(save_file)
        QtCore.QMetaObject.connectSlotsByName(save_file)

    def retranslateUi(self, save_file):
        _translate = QtCore.QCoreApplication.translate
        save_file.setWindowTitle(_translate("save_file", "Save file"))
        self.groupBox.setTitle(_translate("save_file", "Select the desired output file"))
        self.csv_check.setText(_translate("save_file", "CSV"))
        self.shp_check.setText(_translate("save_file", "Shp"))
        self.groupBox_2.setTitle(_translate("save_file", "Save Path"))
        self.save_path_button.setText(_translate("save_file", "Explore..."))
        self.dont_save_button.setText(_translate("save_file", "Don\'t Save"))
        self.save_button.setText(_translate("save_file", "Save"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    save_file = QtWidgets.QWidget()
    ui = Ui_save_file()
    ui.setupUi(save_file)
    save_file.show()
    sys.exit(app.exec_())


# -*- coding: utf-8 -*-
"""

/***************************************************************************
Name                : Interferometric Sections 
Date                : Jan 12, 2021
copyright           : (C) 2020 by Nhzca
email               : santiago.giraldo@sagima.com.co

 ***************************************************************************/

"""

def name():
	return "Heatmap from PS"


def author():
	return "Santiago Giraldo (NHAZCA)"

def authorName():
	return author()

def email():
	return "santiago.giraldo@sagima.com.co"

def icon():
	return "ui/icons/logo_heatmap.png"

def version():
	return "1.1"

def qgisMinimumVersion():
	return "3.1"

def classFactory(iface):
	from .HeatMap_plugin import HeatMap_Plugin
	return HeatMap_Plugin(iface)
# -*- coding: utf-8 -*-

"""
/***************************************************************************
Name                : PS on Linear Infrastructures
Description         : Scancy è sempre il numero 1
Date                : August 2020
copyright           : (C) 2020 by Nhzca
email               : michele.gaeta@nhazca.com

 ***************************************************************************/
"""

from qgis.PyQt.QtCore import Qt, QRegExp, QDate, QFileInfo, QDir
from qgis.PyQt.QtGui import QIcon, QCursor, QPixmap
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox, QApplication
from qgis.core import QgsMapLayer, QgsWkbTypes, QgsFeature, QgsFeatureRequest, QgsMessageLog, QgsDataSourceUri, QgsVectorLayer
from .ui import resources_rc # import resources_rc
from .launcher import mainWindow, updaterDialog, Signals
from PyQt5.QtCore import QThread

class LinearInfrastuctures_Plugin:

	def __init__(self, iface):
		self.iface 		= iface
		self.featFinder = None
		self.features 	= None
		self.values 	= None
		self.updater = updaterDialog()
		self.loader 	= AttributeLoader()
		self.loader.signals.loader.connect(self.setFeatAndVal)
		self.loader.signals.status.connect(self.updateUpdaterStatus)
		self.loader.signals.progress.connect(self.unpdateUpdaterPbar)
		

	def updateUpdaterStatus(self, val):
		self.updater.label.setText(val)

	def unpdateUpdaterPbar(self, val):
		self.updater.progressBar.setValue(val)

	def setFeatAndVal(self, signal):
		self.features 	= self.loader.fields
		self.values 	= self.loader.attributes
		dlg = mainWindow(self.features,self.values, self.iface, self.layer)
		self.updater.close()
		dlg.show()#exec_()
		dlg.exec_()

	# 

	def run(self):
		# create a maptool to select a point feature from the canvas
		print("run")
		# print(self.iface.mapCanvas())
		
		if not self.featFinder:
			from .MapTools import SendPointToolCoordinates
			layer, self.canvas = self.iface.activeLayer(), self.iface.mapCanvas()

			self.send_point_tool_coordinates = SendPointToolCoordinates(self.canvas,self)
			self.canvas.setMapTool(self.send_point_tool_coordinates)
			self.send_point_tool_coordinates.signals.done.connect(self.onPointClicked)
			# self.featFinder = SendPointToolCoordinates(self.iface.mapCanvas())
			# self.featFinder.setAction( self.action )
			# self.featFinder.pointEmitted.connect(self.onPointClicked)

		# enable the maptool and set a message in the status bar
		# print(dir(self.iface.mapCanvas()))
		# self.featFinder.startCapture()
		# self.iface.mainWindow().statusBar().showMessage( "Click on a point feature in canvas" )
		
	def test(self):
		print("test")
	
	def onPointClicked(self):
		print("clicked")
		self.layer = self.iface.activeLayer()
		# print(self.layer.crs())
		if not self.layer or self.layer.type() != QgsMapLayer.VectorLayer or self.layer.geometryType() != QgsWkbTypes.PointGeometry:
			QMessageBox.information(self.iface.mainWindow(), "PS on Linear Infrastuctures", "Select a vector layer and try again.")
			self.canvas.unsetMapTool( self.send_point_tool_coordinates )
			return
		QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
		try:
			#dlg = 
			self._onPointClicked( self.layer )
		finally:
			QApplication.restoreOverrideCursor()
			self.canvas.unsetMapTool( self.send_point_tool_coordinates )
		

	def _onPointClicked(self, ps_layer):
		fid, fattr = [], []
		fsel = ps_layer.selectedFeatures()
		if len(fsel) == 0:
			QMessageBox.information(self.iface.mainWindow(), "PS on Linear Infrastuctures", "No Points in the selected layer")
			return

		# print(len(fsel))
		self.loader.setter(ps_layer)
		self.updater.label.setText('Reading selected attributes...')
		self.updater.show()
		self.updater.raise_()
		#self.loader.setPriority(QThread.NormalPriority)
		self.loader.start()
		
		

class AttributeLoader(QThread):
	def __init__(self, parent = None):
		super(AttributeLoader, self).__init__(parent)
		self.ps_layer	= None
		self.fields		= []
		self.attributes = []
		self.signals = Signals()
        
	def setter(self, ps_layer):
		self.ps_layer 	= ps_layer
	
	def run(self):
		
		fattr 	= []
		fid 	= []

		features = self.ps_layer.selectedFeatures()
		nFeat = len(features)

		i = 0
		for index in features:
			i+=1
			self.signals.progress.emit(100*i/nFeat)
			fattr.append( index.attributes() )
			fid.append( fattr[0][0] )		
		if fid is None:
			return

		infoFields = []	# hold the index->name of the fields containing info to be displayed

		ps_source 	= self.ps_layer.source()
		ps_fields 	= self.ps_layer.dataProvider().fields()
		providerType = self.ps_layer.providerType()
		# print(providerType)

		if providerType == 'ogr' or providerType == 'delimitedtext':# and ps_source.lower().split('|')[0].endswith( ".shp" ):
			for fld in ps_fields:
				infoFields.append(fld.name())
		# print(f"infoFields: {infoFields}")
		self.fields 	= infoFields
		self.attributes = fattr
		self.signals.loader.emit(0)

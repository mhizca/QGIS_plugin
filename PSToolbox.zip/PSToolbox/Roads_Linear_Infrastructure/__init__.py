# -*- coding: utf-8 -*-

"""
/***************************************************************************
Name                : PS Trend Change Detection
Description         : Scancy è sempre il numero 1
Date                : Jul 25, 2012
copyright           : (C) 2020 by Nhzca
email               : michele.gaeta@nhazca.com

 ***************************************************************************/
"""


def name():
	return "(roads)PS on Linear Infrastructures"

def description():
	return "Scancy The Best"

def author():
	return "Michele Gaeta (NHAZCA)"

def authorName():
	return author()

def email():
	return "michele.gaeta@nhazca.com"

def icon():
	return "icons/logoLinear_roads.png"

def version():
	return "1.0"

def qgisMinimumVersion():
	return "3.1"

def classFactory(iface):
	from .LinearInfrastructures_plugin import LinearInfrastuctures_Plugin
	return LinearInfrastuctures_Plugin(iface)


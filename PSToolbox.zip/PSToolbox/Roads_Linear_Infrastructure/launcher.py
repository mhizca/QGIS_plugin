from .ui import Ui_LinearInfrastructures
from ..ui.Progress_ui import  Ui_ProgressMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
import sys
from multiprocessing import freeze_support
freeze_support()
# from .core import mainFunc, getRoads
import json
import requests
import os
import pandas as pd
import subprocess
from shutil import copyfile

class Signals(QtCore.QObject):
    done = QtCore.pyqtSignal(int)
    status = QtCore.pyqtSignal(str)
    progress = QtCore.pyqtSignal(float)
    loader = QtCore.pyqtSignal(int)

class Parameters(object):
    
    def __init__(self, path = None):

        self.binLength = 1
        self.bufferWidth = 5
        self.windowLength = 20
        self.radio = 3
        self.PSfile = ""
        self.shape_layer = ""
        self.save_path = ""
        self.roads_file = ""
        

        if path:
            self.load(path)

    def dumpJson(self, file):
        with open (file, 'w') as wb:
            wb.write(json.dumps(self.__dict__, separators=(',\n', ': ')))

    def load(self, file):
        try:
            with open(file, 'r') as rb:
                paramJson = json.load(rb)
                for item, value in paramJson.items():
                    if item in self.__dict__:
                        self.__dict__[item] = value
        except:
            self.__init__()

class mainWindow(QtWidgets.QDialog, Ui_LinearInfrastructures):

    def __init__(self, X, Y, parent):
        super(mainWindow, self).__init__(parent.mainWindow())
        self.setupUi(self)
        self.X = X
        self.Y = Y
        self.iface = parent
        self.signal = Signals()
        self.analysis = analysisLauncher(self)
        self.fileName = ''
        self.spinBoxBinsLength.setValue(1)
        self.spinBoxBufferWidth.setValue(5)
        self.spinBoxWindowSize.setValue(20)
        self.set_combobox()
        self.buttonBrowseLoad.clicked.connect(self.load_road_window)
        self.SaveShpButton.clicked.connect(self.save_window)
        self.buttonRun.clicked.connect(self.runAnalysis)
        self.roadsFile = ''
        self.save_path = None
        self.updater = updaterDialog()
        self.analysis.signals.status.connect(self.updateUpdaterStatus)
        self.analysis.signals.progress.connect(self.updateUpdaterPbar)
        self.analysis.signals.done.connect(self.analysisCompleted)
        self.shape_combo.currentIndexChanged.connect(self.shape_combo_change)
        # if not os.path.exists(os.path.join(os.path.dirname(__file__),'.config')):
        #     self.setInstallationPath(first = True)
        # self.actionSet_Installation_Path.triggered.connect(self.setInstallationPath)
       

    def updateUpdaterStatus(self, val):
        self.updater.label.setText(val)

    def updateUpdaterPbar(self, val):
        if val >=0:
            self.updater.progressBar.setRange(0,100)
            self.updater.progressBar.setValue(val)
        elif val ==-1:
            self.updater.progressBar.setRange(0,0)

    # def setInstallationPath(self,first=False):
    #     if first:
    #         reply = QtWidgets.QMessageBox.question(self, 'Installation Path', 'Installation Path not set, Set it now?',
    #         QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
    #         if reply == QtWidgets.QMessageBox.Yes:
    #             direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
    #             if direct[0]:
    #                 config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
    #                 config.write(f"bin_path = {direct[0]}")
    #     else:
    #         direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
    #         if direct[0]:
    #             config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
    #             config.write(f"bin_path = {direct[0]}")

    def analysisCompleted(self, val):
        print('done')
        self.buttonRun.setEnabled(True)
        self.updater.close()
        self.iface.addVectorLayer(os.path.join(self.save_path,"roads.shp"), "roads", "ogr")
        __location__ = os.path.realpath(os.path.join(os.getcwd(),os.path.dirname(__file__)))
        style = os.path.join(__location__, "Style", "colormapLinear.qml" )
        copyfile(style, os.path.join(self.save_path,"roads.qml"))
        self.iface.activeLayer().loadNamedStyle(style)
        self.iface.activeLayer().triggerRepaint()

    def shape_combo_change(self):
        if self.shape_combo.currentText() != "":
            self.shape_radio.setChecked(True)
            self.lineEditLoad.clear()

    def set_combobox(self):
        layers_names = []
        vector_layers_names =[]
        layers_names.append("")
        vector_layers_names.append("")
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsMapLayer.VectorLayer:
                vector_layers_names.append(layer.name())
            else:
                layers_names.append(layer.name())
        self.shape_combo.addItems(vector_layers_names)
        

    def save_window(self):
        direct = QtWidgets.QFileDialog.getExistingDirectory(self,"Save path ...")
        self.save_path = direct
        self.SaveShpText.insert(direct)

    def load_road_window(self):
        direct = QtWidgets.QFileDialog.getOpenFileName(self,"Load Roads File ...","","TXT files (*.txt)")
        self.roadsFile = direct[0]
        self.lineEditLoad.insert(direct[0])
        self.radioButtonLoad.setChecked(True)
        self.shape_combo.setCurrentIndex(0) 

    def runAnalysis(self):
        
        binLength = self.spinBoxBinsLength.value()
        bufferWidth = self.spinBoxBufferWidth.value()
        windowLength = self.spinBoxWindowSize.value()
        self.shape_layer = self.shape_combo.currentText()
        if self.radioButtonLoad.isChecked():
            self.radio = 1
        elif self.shape_radio.isChecked():
            self.radio = 2
        elif self.radioButtonGet.isChecked():
            self.radio = 3  
        if self.save_path:
            r = self.analysis.setParametersAndWriteFiles(binLength, bufferWidth, windowLength, self.shape_layer, self.radio, self.X, self.Y, self.save_path, self.roadsFile)
            if r == 0:
                self.buttonRun.setEnabled(False)
                self.updater.show()
                self.updater.raise_()
                self.analysis.start()
        else:
            QtWidgets.QMessageBox.warning(self, "Save Path", "Please define a path for the output file before running")

class analysisLauncher(QtCore.QThread):

    def __init__(self, parent = None):
        super(analysisLauncher, self).__init__(parent)
        self.fileName       = ''
        self.nTop           = 0
        self.w0             = 0
        self.peakHeight     = 0
        self.maxNumberOfPS  = 0
        self.Thresholds     = {}
        self.fields         = []
        self.values         = []
        self.signals        = Signals()
        self.parent = parent
        
    

    def setParametersAndWriteFiles(self, binsLength, bufferWidth, windowLength,shape_layer,radio, fields, values, save_path, roadsFile = ''):
        if os.path.exists(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config')):
            with open(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config'),'r') as f:
                line = f.readline()
                if 'bin_path' in line:
                    self.exe = line.split('=')[-1].strip()
            self.radio=radio
            self.parameters = Parameters()
            self.parameters.save_path = save_path
            self.parameters.binLength = binsLength
            self.parameters.bufferWidth = bufferWidth
            self.parameters.windowLength = windowLength
            self.parameters.radio = radio
            data_path = os.path.join(self.parameters.save_path,"data.csv")
            self.parameters.PSfile = data_path
            self.shape_layer = shape_layer
            if shape_layer != "":
                shp_layer = QgsProject.instance().mapLayersByName(shape_layer)[0].source()
            else:
                shp_layer = shape_layer
            self.parameters.shape_layer = shp_layer
            self.parameters.roads_file = roadsFile
            self.parametersPath = os.path.join(self.parameters.save_path, 'parameters.json')

            table = []
            for index in values:
                attribute = index
                table.append(list(attribute))

            infoFields = []
            for field in fields:
                infoFields.append(field)

            df = pd.DataFrame(table,  columns = infoFields)
            csv_doc = self.parameters.PSfile
            df.to_csv(csv_doc)
            return 0
        else:
            QtWidgets.QMessageBox.warning(self.parent, "No Installation Path", "No Installation Path Selected, go to Settings and set it.")
            return 1
        
        
    def run(self):
        if self.radio == 2:
            self.signals.status.emit("Reading Shape File...")
            roads = self.read_shp()
            self.parameters.roads_file = os.path.join(self.parameters.save_path,"OSMRoad.txt")
        self.parameters.dumpJson(self.parametersPath)
        args=[self.exe, '-p','roads-linearInfrastructure', '-f', self.parametersPath ]
        print(args)
        if sys.platform.startswith('win'):
            proc = subprocess.Popen(args, shell=True)
            self.signals.status.emit("Computing values on roads...")
            self.signals.progress.emit(-1)
            proc.wait()
        else:
            proc = subprocess.Popen(args, shell=False)
            self.signals.status.emit("Computing values on roads...")
            self.signals.progress.emit(-1)
            proc.wait()
        print("RUN")
        self.signals.done.emit(0)
    
    def read_shp(self):
        # print(QgsProject.instance().mapLayersByName(self.shape_layer))
        shplayer = QgsProject.instance().mapLayersByName(self.shape_layer)[0]
        out_file = os.path.join(self.parameters.save_path,"OSMRoad.txt")
        temp_file = open(out_file,'w')
        
        roads = []
        counter = 0
        len_features = 100
        for feature in shplayer.getFeatures():
            counter +=1
            geom = feature.geometry()
            geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
            
            if geom.type() == QgsWkbTypes.LineGeometry:
                if geomSingleType:
                    x = geom.asPolyline()
                else:
                    x = geom.asMultiPolyline()
                    if counter > 1:
                        
                        roads.append(temp)
                    temp_file.write("*\n")
                    temp = []
                    for points in x[0]:
                        temp_file.write(f"({points.y()},{points.x()})\n")
                        temp.append((points.y(),points.x()))
                       
            attrs = feature.attributes()
            
            self.signals.progress.emit(counter/len_features*100)
        roads.append(temp)
        temp_file.close()
        return roads

class updaterDialog(QtWidgets.QMainWindow, Ui_ProgressMainWindow):
    def __init__(self, parent=None, text = "Dowload in progress... "):
        super(updaterDialog, self).__init__(parent)
        self.setupUi(self)
        self.label.setText(text)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.parent         = parent
        self.progressBar    = QtWidgets.QProgressBar(self.centralwidget)
        self.progressBar.setMaximumSize(QtCore.QSize(16777215, 15))
        self.progressBar.setProperty("value", 0)
        self.progressBar.setObjectName("progressBar")
        self.gridLayout.addWidget(self.progressBar, 1, 0, 1, 1)
        #self.spinner        = None
   
    def updateProgressBar(self, val):
        self.progressBar.setValue(val)

    def updateStatus(self, status):  
        self.label.setText(status)
         


from .ui import Ui_Interferometric_Sections, Ui_save_file#, Ui_ProgressMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.gui import QgsMapToolEmitPoint, QgsMapCanvas, QgsRubberBand
import os
import json
import pandas as pd
import sys
import subprocess
from multiprocessing import freeze_support
freeze_support()

class Signals(QtCore.QObject):
	done_line = QtCore.pyqtSignal(int)
	save_done = QtCore.pyqtSignal(bool)
	status = QtCore.pyqtSignal(str)
	progress = QtCore.pyqtSignal(float)
	done_main = QtCore.pyqtSignal(int)

class Parameters(object):
    
	def __init__(self, path = None):

		self.pointsFile = ''
		self.PSfile = ''
		self.buff_size = 0
		self.bin_size = 0
		self.delta_vel = 0
		self.vel = False
		self.media = False
		self.y_lim = 0
		self.filter_HF = 0
		self.filter_intensity = 0
		self.velocity_output = False
		self.displacement_output = False
		self.outPath = ''
		self.saveCsv = True
		self.saveShp = False
		self.save = True
		if path:
			self.load(path)

	def dumpJson(self, file):
		with open (file, 'w') as wb:
			wb.write(json.dumps(self.__dict__, separators=(',\n', ': ')))

	def load(self, file):
		try:
			with open(file, 'r') as rb:
				paramJson = json.load(rb)
				for item, value in paramJson.items():
					if item in self.__dict__:
						self.__dict__[item] = value
		except:
			self.__init__()

class mainWindow(QtWidgets.QDialog, Ui_Interferometric_Sections):

	def __init__(self, parent):
		super(mainWindow, self).__init__(parent.mainWindow())
		self.setupUi(self)
		self.iface = parent
		self.line_point1 = []
		self.line_point2 = []
		self.line_points = []
		self.signals = Signals()
		self.FilterHFValue.addItems(["Do not filter", "Add filtered trend","Show only filtered results"])
		self.BufferSizeValue.setEnabled(False)
		self.BufferSizeValue.setValue(50)
		self.BinSizeValue.setEnabled(False)
		self.BinSizeValue.setValue(0.01)
		self.DeltaVelValue.setEnabled(False)
		self.DeltaVelValue.setValue(0)
		self.VelValue.setEnabled(False)
		self.VelValue.setValue(1)
		self.AverageValue.setEnabled(False)
		self.AverageValue.setChecked(True)
		self.MinYValue.setEnabled(False)
		self.MinYValue.setValue(-30)
		self.MaxYValue.setEnabled(False)
		self.MaxYValue.setValue(30)
		self.FilterHFValue.setEnabled(False)
		self.FilterIntensityValue.setEnabled(False)
		self.runButton.clicked.connect(self.run_button)
		self.canvas = self.iface.mapCanvas()
		self.startingMapTool = self.canvas.mapTool()
		self.toolDraw = LineMapTool(self.canvas,self.iface)
		self.savedlg = FolderSelector(parent=self)

		# with open(os.path.join(os.path.dirname(__file__),'.config'),'r') as f:
		# 	line = f.readline()
		# 	if 'bin_path' in line:
		# 		self.exe = line.split('=')[-1].strip()
		self.analysisLauncher = AnalysisLauncher(self)
		self.savedlg.signals.save_done.connect(self.run_analysis)
		self.toolDraw.signals.done_line.connect(self.linedone)
		self.CreateLineButton.clicked.connect(self.create_line)
		self.SelectPointButton.clicked.connect(self.write_points)
		# if not os.path.exists(os.path.join(os.path.dirname(__file__),'.config')):
		# 	self.setInstallationPath(first = True)
		# self.actionSet_Installation_Path.triggered.connect(self.setInstallationPath)
		
	# def setInstallationPath(self,first=False):
	# 	if first:
	# 		reply = QtWidgets.QMessageBox.question(self, 'Installation Path', 'Installation Path not set, Set it now?',
    #     	QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
	# 		if reply == QtWidgets.QMessageBox.Yes:
	# 			direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
	# 			if direct[0]:
	# 				config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 				config.write(f"bin_path = {direct[0]}")
	# 	else:
	# 		direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
	# 		if direct[0]:
	# 			config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 			config.write(f"bin_path = {direct[0]}")
	# 			config.close()
	
	def create_line(self):
		self.canvas = self.iface.mapCanvas()
		self.clear()
		self.toolDraw.predclick = False
		self.draw()

	def run_button(self):
		self.savedlg.show()		
			
	def run_analysis(self):
		if self.line_point1:	
			self.signals.status.emit('Computing Values')
			ret = self.analysisLauncher.setParametersAndWriteFiles()
			if ret is None:
				QtWidgets.QMessageBox.warning(self, "Error", "Unable to read attributes")
				return
			#self.updater.show()
			self.analysisLauncher.start()
		else:
			QtWidgets.QMessageBox.warning(self, "No points Selected", "Please select Points")

	def write_points(self):
		if self.SelectPointButton.text() == "Change Points":
			self.StartLat.setEnabled(True)
			self.StartLon.setEnabled(True)
			self.EndLat.setEnabled(True)
			self.EndLon.setEnabled(True)
			self.SelectPointButton.setText("Select Point")
			
		else:
			start_lat = float(self.StartLat.text())
			start_lon = float(self.StartLon.text())
			end_lat = float(self.EndLat.text())
			end_lon = float(self.EndLon.text())
			self.line_point1 = [start_lat,start_lon]
			self.line_point2 = [end_lat,end_lon]
			self.BufferSizeValue.setEnabled(True)
			self.BinSizeValue.setEnabled(True)
			self.DeltaVelValue.setEnabled(True)
			self.VelValue.setEnabled(True)
			self.AverageValue.setEnabled(True)
			self.MinYValue.setEnabled(True)
			self.MaxYValue.setEnabled(True)
			self.FilterHFValue.setEnabled(True)
			self.FilterIntensityValue.setEnabled(True)
	
	def draw(self):
		"""Activates draw tool"""
		
		self.startingMapTool = self.canvas.mapTool()
		self.canvas.setMapTool(self.toolDraw)
	
	def linedone(self):

		# self.canvas.setMapTool(self.startingMapTool)
		self.line_points = self.toolDraw.points
		# print(self.line_points[0])
		if self.line_points:
			start_lat = "{:.7f}".format( self.line_points[0][1])
			start_lon = "{:.7f}".format(self.line_points[0][0])
			end_lat = "{:.7f}".format(self.line_points[1][1])
			end_lon = "{:.7f}".format(self.line_points[1][0])
			self.line_point1 = [float(start_lat),float(start_lon)]
			self.line_point2 = [float(end_lat),float(end_lon)]
			self.StartLat.setText(start_lat)
			self.StartLon.setText(start_lon)
			self.EndLat.setText(end_lat)
			self.EndLon.setText(end_lon)
			self.StartLat.setEnabled(False)
			self.StartLon.setEnabled(False)
			self.EndLat.setEnabled(False)
			self.EndLon.setEnabled(False)
			self.SelectPointButton.setText("Change Points")
			self.BufferSizeValue.setEnabled(True)
			self.BinSizeValue.setEnabled(True)
			self.DeltaVelValue.setEnabled(True)
			self.VelValue.setEnabled(True)
			self.AverageValue.setEnabled(True)
			self.MinYValue.setEnabled(True)
			self.MaxYValue.setEnabled(True)
			self.FilterHFValue.setEnabled(True)
			self.FilterIntensityValue.setEnabled(True)
		
	def clear(self):
		self.toolDraw.reset()

	def closeEvent(self, event):
		self.toolDraw.reset()
		self.canvas.unsetMapTool(self.toolDraw)

class AnalysisLauncher(QtCore.QThread):

	def __init__(self,parent = None):
		super(AnalysisLauncher, self).__init__(parent)
		self.signals = Signals()
		self.exe  = None
		self.parametersPath = None 
		self.parent = parent
	
	def setParametersAndWriteFiles(self):
		if os.path.exists(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config')):
			with open(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config'),'r') as f:
				line = f.readline()
				if 'bin_path' in line:
					self.exe = line.split('=')[-1].strip()

			parameters = Parameters()
			parameters.outPath = self.parent.savedlg.save_path
			parameters.pointsFile = os.path.join(parameters.outPath,"points.json")
			parameters.saveCsv = self.parent.savedlg.csv_file
			parameters.saveShp = self.parent.savedlg.shp_file
			parameters.save = self.parent.savedlg.save
			parameters.buff_size = self.parent.BufferSizeValue.value()
			parameters.bin_size = self.parent.BinSizeValue.value()
			parameters.delta_vel = self.parent.DeltaVelValue.value()
			parameters.vel = self.parent.VelValue.value()
			parameters.media = self.parent.AverageValue.isChecked()
			parameters.velocity_output = self.parent.velocityradio.isChecked()
			parameters.displacement_output = self.parent.displacementradio.isChecked()
			maxy = self.parent.MaxYValue.value()
			miny = self.parent.MinYValue.value()
			parameters.y_lim = (miny,maxy)
			parameters.filter_HF = self.parent.FilterHFValue.currentIndex()
			parameters.filter_intensity = self.parent.FilterIntensityValue.value()/100
			parameters.PSfile = os.path.join(parameters.outPath,"selection.csv")
			self.parametersPath = os.path.join(parameters.outPath, 'parameters.json')
			parameters.dumpJson(self.parametersPath)

			layer = self.parent.iface.activeLayer()
			fsel  = layer.selectedFeatures()
			table = []

			if fsel[0].attributes()[0] is None:
				return None

			for index in fsel:
				attribute = index.attributes()
				table.append(list(attribute))

			infoFields = []
			ps_fields = layer.dataProvider().fields()
			for field in ps_fields:
				infoFields.append(field.name())

			df = pd.DataFrame(table,  columns = infoFields)
			csv_doc = parameters.PSfile
			df.to_csv(csv_doc)

			points = self.parent.line_points
			_points = []
			for p in range(len(points)):
				_points.append([points[p][0],points[p][1]])
			
			with open(parameters.pointsFile, 'w') as f:
				json.dump(_points, f)
		else:
			QtWidgets.QMessageBox.warning(self.parent, "No Installation Path", "No Installation Path Selected, go to Settings and set it.")

		return 0

	def run(self):
		self.signals.status.emit('Computing Values')
		args=[self.exe, '-p','sections', '-f', self.parametersPath ]
		print(args)
		# print(sys.platform)
		if sys.platform.startswith('win'):
			proc = subprocess.Popen(args, shell=True)
			proc.wait()
		else:
			proc = subprocess.Popen(args, shell=False)
			# self.signals.status.emit("Performing Vectorial Decomposition")
			# self.signals.progress.emit(-1)
			proc.wait()
	
class LineMapTool(QgsMapToolEmitPoint, QtCore.QThread):
    
	def __init__(self, canvas,iface):
		self.canvas = canvas
		self.iface = iface
		QgsMapToolEmitPoint.__init__(self, self.canvas)
		self.rubberBand = QgsRubberBand(self.canvas, True)
		self.rubberBand.setColor(QtGui.QColor(235,36,21, 150))
		self.rubberBand.setFillColor(QtGui.QColor(255,79,66,40))
		self.rubberBand.setWidth(3)
		self.signals        = Signals()
		self.points = []
		self.finished = False
		self.poly_bbox = False
		self.right_click_flag = False
		self.predclick = False
		self.reset()
		self.layer = self.iface.activeLayer()
		
	def reset(self):
		self.rubberBand.reset(True)
		self.poly_bbox = False
		self.points.clear()
	
	
	def canvasMoveEvent(self, e):
		if len(self.points)>0 and not self.right_click_flag:# and len(self.points)<2:
			point = self.toMapCoordinates(e.pos())
			self.rubberBand.removePoint(-1)
			self.rubberBand.addPoint(point, True)
	

	def keyPressEvent(self, e):
		
		if (e.key() == 16777216): # press ESC
			self.reset()
		if (e.key() == 16777220): # press Enter
			self.finishPolygon()

	def canvasReleaseEvent(self, e):
		
		if self.predclick:
			self.predclick = False
			self.right_click_flag = False
			self.reset()

		if e.button() == QtCore.Qt.LeftButton:
			self.click_point_2 = self.toLayerCoordinates(self.layer,e.pos())
			self.click_point = self.toMapCoordinates(e.pos())
			self.right_click_flag = False
			self.points.append(self.click_point_2)
			self.rubberBand.addPoint(self.click_point, True)
		
		if e.button() == QtCore.Qt.RightButton:
			if len(self.points) > 1:
				self.predclick = True
				self.right_click_flag = True
				self.rubberBand.removePoint(-1)
				#self.rubberBand.removePoint(-1)
			else:
				self.reset()
			self.finishPolygon()
			
		#self.rubberBand.show()

	def finishPolygon(self):		
		self.signals.done_line.emit(0)
		
	def getPoints(self):
		self.rubberBand.reset(True)
		return self.points

class FolderSelector(QtWidgets.QDialog, Ui_save_file):

	def __init__(self, parent=None):
		QtWidgets.QDialog.__init__(self, parent)
		self.setupUi(self)
		self.csv_file = False
		self.shp_file = False
		self.save_path = ""
		self.save = False
		self.dont_save = False
		self.save_path_button.clicked.connect(self.save_window)
		self.save_button.clicked.connect(self.save_button_clicked)
		self.dont_save_button.clicked.connect(self.dont_save_button_clicked)
		self.signals = Signals()
		# self.signals.save_done.emit(False)

	def save_window(self):
		direct = QtWidgets.QFileDialog.getExistingDirectory(self,"Save path ...")
		self.save_path = direct
		self.save_path_text.insert(direct)
	
	def save_button_clicked(self):
		self.csv_file = self.csv_check.isChecked()
		self.shp_file = self.shp_check.isChecked()
		# print(self.csv_file, self.shp_file, self.save_path)
		if self.csv_file or self.shp_file:
			if self.save_path != "":
				self.save = True
				self.dont_save = False
				#self.done_signal()
				self.signals.save_done.emit(True)
				self.close()
			else:
				QtWidgets.QMessageBox.warning(self, "Save Path", "Please define a path for the output file before running")
		else:
			QtWidgets.QMessageBox.warning(self, "No file type Selected", "Please select one or more file types to be saved")
	
	def dont_save_button_clicked(self):
		self.shp_file = False
		self.csv_file = False
		self.save_path = ""
		self.dont_save = True
		self.save = False
		#self.done_signal()
		self.signals.save_done.emit(True)
		self.close()

	

		

	


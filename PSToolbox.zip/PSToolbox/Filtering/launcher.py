from ..ui.Progress_ui import  Ui_ProgressMainWindow
from .ui.ExportSmoothed_ui import Ui_SmoothMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
from qgis.core import QgsProject,NULL
from qgis.PyQt.QtCore import Qt, QRegExp, QDate, QDateTime, QFileInfo, QDir
# from .core import Export
import matplotlib.pyplot as plt
import re
import numpy as np
import os
import pandas as pd
import time
import json
import sys
import subprocess

class Signals(QtCore.QObject):
	done = QtCore.pyqtSignal(int)
	status = QtCore.pyqtSignal(str)
	progress = QtCore.pyqtSignal(float)
	doneloader = QtCore.pyqtSignal(int)

class Parameters(object):
    
	def __init__(self, path = None):

		self.DetrendSpan_value = 5
		self.Smoothing_value = 30
		self.type_combo = "Local Linear Regrerssion"
		self.Displacements = ""
		self.PSfile = ""
		self.TimeASC = ""
		self.other = ""
		self.save_path = ""
		self.file_name = ""
		

		if path:
			self.load(path)

	def dumpJson(self, file):
		with open (file, 'w') as wb:
			wb.write(json.dumps(self.__dict__, separators=(',\n', ': ')))

	def load(self, file):
		try:
			with open(file, 'r') as rb:
				paramJson = json.load(rb)
				for item, value in paramJson.items():
					if item in self.__dict__:
						self.__dict__[item] = value
		except:
			self.__init__()

class mainWindow(QtWidgets.QDialog, Ui_SmoothMainWindow):

	def __init__(self,  parent):
		super(mainWindow, self).__init__(parent.mainWindow())
		self.setupUi(self)
		self.save_path = ""
		self.iface = parent
		self.set_combobox()
		self.signals = Signals()
		self.type_combo.addItems(["Moving Averages","Local Linear Regrerssion","Robust Local Linear Regrerssion"])
		self.Layer1_combo.currentIndexChanged.connect(self.combo_layer1)
		self.Save_button.clicked.connect(self.save_window)
		self.Export_button.clicked.connect(self.export_smoothed)
		self.loader 	= AttributeLoader()
		self.updater = updaterDialog()
		self.runexport = RunExport()
		self.loader.signals.doneloader.connect(self.setFeatAndVal)
		self.loader.signals.status.connect(self.updateUpdaterStatus)
		self.loader.signals.progress.connect(self.updateUpdaterPbar)
		self.runexport.signals.done.connect(self.export_done)
		self.runexport.signals.status.connect(self.updateUpdaterStatus)
		self.runexport.signals.progress.connect(self.updateUpdaterPbar)
		self.DetrendSpan_value.setValue(5)
		self.Smoothing_value.setValue(30)
		self.type_combo.setCurrentIndex(1)
		# if not os.path.exists(os.path.join(os.path.dirname(__file__),'.config')):
		# 	self.setInstallationPath(first = True)
		# self.actionSet_Installation_Path.triggered.connect(self.setInstallationPath)

	
	def updateUpdaterStatus(self, val):
		self.updater.label.setText(val)

	def updateUpdaterPbar(self, val):
		if val >=0:
			self.updater.progressBar.setRange(0,100)
			self.updater.progressBar.setValue(val)
		elif val ==-1:
			self.updater.progressBar.setRange(0,0)

	# def setInstallationPath(self,first=False):
	# 	if first:
	# 		reply = QtWidgets.QMessageBox.question(self, 'Installation Path', 'Installation Path not set, Set it now?',
    #     	QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
	# 		if reply == QtWidgets.QMessageBox.Yes:
	# 			direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File",filter='Executable (*.exe)')
	# 			if direct[0]:
	# 				config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 				config.write(f"bin_path = {direct[0]}")
	# 	else:
	# 		direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File",filter='Executable (*.exe)')
	# 		if direct[0]:
	# 			config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 			config.write(f"bin_path = {direct[0]}")

	def export_done(self):
		print("Done!!")
		print(f"Total time Elapsed: {time.time()-self.time1}")
		self.updater.close()
	
	def setFeatAndVal(self, signal):
		self.fields 	= self.loader.fields
		self.values 	= self.loader.attributes
		self.Save_text.setEnabled(True)
		self.Save_button.setEnabled(True)
		self.DetrendSpan_value.setEnabled(True)
		self.Smoothing_value.setEnabled(True)
		self.type_combo.setEnabled(True)
		lat = 0
		lon=0
		height = 0
		vel = 0
		coher = 0
		sigma_vel = 0
		min_temp = 0
		self.Displacements = 0
		for i,fld in enumerate(self.fields):
			if "LAT" == fld:
				lat = i
				self.index_lat = i
			elif "LON" == fld:
				lon = i
				self.index_lon = i
			elif "HEIGHT" == fld:
				height = i
				self.index_height = i
			elif "VEL" == fld:
				vel = i
				self.index_vel = i
			elif "COHER" == fld:
				coher = i
			elif "SIGMA VEL" == fld:
				sigma_vel = i
			elif QRegExp( "[0-9]{8}", Qt.CaseInsensitive ).indexIn( fld ) >= 0:
				if not self.TimeASC:
					counter = i
				fil = re.search("[0-9]{8}",fld).group()
				self.TimeASC.append(QDate.fromString( fil, "yyyyMMdd" ).toPyDate())
		self.other = np.array(self.values)[:,:counter]
		self.Displacements = np.array(self.values)[:,counter:]	

		self.updater.close()

	def export_smoothed(self):
		self.time1 = time.time()
		self.updater.label.setText('Exporting smoothed time series in CSV format...')
		self.updater.progressBar.setValue(0)
		self.updater.show()
		self.updater.raise_()
		self.runexport.setParametersAndWriteFiles(self)
		self.runexport.start()


	def closeEvent(self, event):
		self.updater.close()

	def set_combobox(self):
		layers_names = []
		layers_names.append("")
		for layer in QgsProject.instance().mapLayers().values():
			layers_names.append(layer.name())
		self.Layer1_combo.addItems(layers_names) 

	def combo_layer1(self):
		self.TimeASC= []
		asc = self.Layer1_combo.currentText()
		layer = QgsProject.instance().mapLayersByName(asc)[0]
		self.loader.setter(layer)
		self.updater.label.setText('Reading Layer attributes...')
		self.updater.show()
		self.updater.raise_()
		self.loader.start()

	def save_window(self):
		direct = QtWidgets.QFileDialog.getSaveFileName(self, "Save Path", filter='Comma Separated Values (*.csv)')
		
		self.Save_text.clear()
		self.save_path = direct[0]
		self.Save_text.insert(direct[0])
		if direct:
			self.Export_button.setEnabled(True)



class AttributeLoader(QtCore.QThread):
	def __init__(self, parent = None):
		super(AttributeLoader, self).__init__(parent)
		self.ps_layer	= None
		self.fields		= []
		self.attributes = []
		self.signals = Signals()
        
	def setter(self, ps_layer):
		self.fields		= []
		self.attributes = []
		self.ps_layer 	= ps_layer
	
	def run(self):
		self.fields		= []
		self.attributes = []
		fattr 	= []
		fid 	= []
		features = self.ps_layer.getFeatures()
		nFeat = len(self.ps_layer)
		i = 0
		for index in features:
			i+=1
			attr = []
			self.signals.progress.emit(100*i/nFeat)
			attributes = np.around(np.array(list(index.attributes()))*1e6)/1e6
			attributes[attributes==NULL] = np.nan
			attr = attributes
			fattr.append( attr )
			
			fid.append( fattr[0][0] )
		if fid is None:
			return

		infoFields = []	# hold the index->name of the fields containing info to be displayed

		ps_source 	= self.ps_layer.source()
		ps_fields 	= self.ps_layer.dataProvider().fields()
		providerType = self.ps_layer.providerType()

		for fld in ps_fields:
			infoFields.append(fld.name())
		
		self.fields 	= infoFields
		self.attributes = fattr
		self.signals.doneloader.emit(0)

class RunExport(QtCore.QThread):
	
	def __init__(self, parent = None):
		super(RunExport, self).__init__(parent)
		self.signals = Signals()

	def run(self):
		
		args=[self.exe, '-p','filtering', '-f', self.parametersPath ]
		self.signals.status.emit("Exporting smoothed time series in CSV format...")
		self.signals.progress.emit(-1)
		print(args)
		if sys.platform.startswith('win'):
			proc = subprocess.Popen(args, shell=True)
			proc.wait()
		else:
			os.system(self.exe + '&')
		print("RUN")
		self.signals.done.emit(0)

	def setParametersAndWriteFiles(self,main):
		if os.path.exists(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config')):
			with open(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config'),'r') as f:
				line = f.readline()
				if 'bin_path' in line:
					self.exe = line.split('=')[-1].strip()

			parameters = Parameters()
			pn,fn =  os.path.split(main.save_path)
			parameters.save_path = pn
			parameters.file_name = fn
			
			parameters.DetrendSpan_value = main.DetrendSpan_value.value()
			parameters.Smoothing_value = main.Smoothing_value.value()
			parameters.type_combo = main.type_combo.currentText()
			others_path = os.path.join(parameters.save_path,"others.csv")
			parameters.other = others_path
			Dsiplacements_path = os.path.join(parameters.save_path,"Displacements.csv")
			parameters.Displacements = Dsiplacements_path
			data_path = os.path.join(parameters.save_path,"data.csv")
			parameters.PSfile = data_path
			time_asc_txt = os.path.join(parameters.save_path,"time.csv")
			parameters.TimeASC = time_asc_txt
			self.parametersPath = os.path.join(parameters.save_path, 'parameters.json')
			parameters.dumpJson(self.parametersPath)
			time_asc = main.TimeASC
			df_time_asc = pd.DataFrame(time_asc)
			df_displacements = pd.DataFrame(main.Displacements)
			csv_displacements = parameters.Displacements
			df_displacements.to_csv(csv_displacements)
			df_others = pd.DataFrame(main.other)
			csv_others = parameters.other
			df_others.to_csv(csv_others)
			csv_time_asc = parameters.TimeASC
			df_time_asc.to_csv(csv_time_asc)
			table = []
			for index in main.values:
				attribute = index
				table.append(list(attribute))
			infoFields = []
			for field in main.fields:
				infoFields.append(field)
			df = pd.DataFrame(table,  columns = infoFields)
			csv_doc = parameters.PSfile
			df.to_csv(csv_doc)
		else:
			QtWidgets.QMessageBox.warning(main, "No Installation Path", "No Installation Path Selected, go to Settings and set it.")
		
		return 0

class updaterDialog(QtWidgets.QMainWindow, Ui_ProgressMainWindow):
    def __init__(self, parent=None, text = "Dowload in progress... "):
        super(updaterDialog, self).__init__(parent)
        self.setupUi(self)
        self.label.setText(text)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.parent         = parent
        self.progressBar    = QtWidgets.QProgressBar(self.centralwidget)
        self.progressBar.setMaximumSize(QtCore.QSize(16777215, 15))
        self.progressBar.setProperty("value", 0)
        self.progressBar.setObjectName("progressBar")
        self.gridLayout.addWidget(self.progressBar, 1, 0, 1, 1)
   
    def updateProgressBar(self, val):
        self.progressBar.setValue(val)

    def updateStatus(self, status):  
        self.label.setText(status)
        

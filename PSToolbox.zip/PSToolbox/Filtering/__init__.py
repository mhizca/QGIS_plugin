# -*- coding: utf-8 -*-
"""

/***************************************************************************
Name                : Interferometric Sections 
Date                : Jan 12, 2021
copyright           : (C) 2020 by Nhzca
email               : santiago.giraldo@sagima.com.co

 ***************************************************************************/

"""

def name():
	return "Smoothed PS data"


def author():
	return "Santiago Giraldo (NHAZCA)"

def authorName():
	return author()

def email():
	return "santiago.giraldo@sagima.com.co"

def icon():
	return "ui/icons/Filtering_Icon.png"

def version():
	return "0.1"

def qgisMinimumVersion():
	return "3.1"

def classFactory(iface):
	from .SmoothingExport_plugin import SmoothingExport_Plugin
	return SmoothingExport_Plugin(iface)
# -*- coding: utf-8 -*-

"""
/***************************************************************************
Name                : Interferometric Sections
Date                : Jan 12, 2021
copyright           : (C) 2020 by Nhzca
email               : santiago.giraldo@sagima.com.co

 ***************************************************************************/
"""

from qgis.PyQt.QtCore import Qt, QRegExp, QDate, QFileInfo, QDir
from qgis.PyQt.QtGui import QIcon, QCursor
from qgis.PyQt.QtWidgets import QAction, QInputDialog, QMessageBox, QApplication

from qgis.core import QgsMapLayer, QgsWkbTypes, QgsFeature, QgsFeatureRequest, QgsMessageLog, QgsDataSourceUri, QgsVectorLayer

from .launcher import mainWindow
from . import resources_rc


class PS_Toolbox_Plugin:

    def __init__(self, iface):
        self.iface = iface
        self.featFinder = None
        self.running = False

        
        self.last_ps_layerid = None
        self.ts_tablename = None

    def initGui(self):
        
        self.action = QAction( QIcon( ":/ps_toolbox/ui/icons/logonhazca" ), "PS Toolbox", self.iface.mainWindow() )
        self.action.triggered.connect( self.run )
        self.iface.addToolBarIcon( self.action )
        self.iface.addPluginToMenu( "&Permanent Scatterers", self.action )
        

    def unload(self):
        
        self.iface.removeToolBarIcon( self.action )
        self.iface.removePluginMenu( "&Permanent Scatterers", self.action )
        

	
    def run(self):
		        
        dlg = mainWindow(self.iface)
        dlg.show()#exec_()
        dlg.exec_()


	
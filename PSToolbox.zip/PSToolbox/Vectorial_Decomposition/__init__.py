# -*- coding: utf-8 -*-
"""

/***************************************************************************
Name                : Interferometric Sections 
Date                : Jan 12, 2021
copyright           : (C) 2020 by Nhzca
email               : santiago.giraldo@sagima.com.co

 ***************************************************************************/

"""

def name():
	return "Permanent Scatterers Vectorial Decompositor"


def author():
	return "Santiago Giraldo (NHAZCA)"

def authorName():
	return author()

def email():
	return "santiago.giraldo@sagima.com.co"

def icon():
	return "icons/Logo_PS_vectorial_decomp.png"

def version():
	return "1.0"

def qgisMinimumVersion():
	return "3.1"

def classFactory(iface):
	from .PSVectorialDecomp_plugin import PSVectorialDecomp_Plugin
	return PSVectorialDecomp_Plugin(iface)
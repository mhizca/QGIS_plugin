from numpy.lib.function_base import _calculate_shapes
from .ui import Ui_PSVectorialDecompositor
from ..ui.Progress_ui import  Ui_ProgressMainWindow
from qgis.PyQt.QtCore import Qt, QRegExp, QDate, QFileInfo, QDir
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.core import QgsProject,NULL
# from .core import Decomposition
import matplotlib.pyplot as plt
import json
import pandas as pd
import re
import numpy as np
import os
import sys
import subprocess

class Signals(QtCore.QObject):
	done_decomp = QtCore.pyqtSignal(int)
	status = QtCore.pyqtSignal(str)
	progress = QtCore.pyqtSignal(float)
	loaderASC = QtCore.pyqtSignal(int)
	loaderDSC = QtCore.pyqtSignal(int)

class Parameters(object):
    
	def __init__(self, path = None):

		self.time_asc_file = ""
		self.time_dsc_file = ""
		self.values_asc_file = ""
		self.values_dsc_file = ""
		self.save_path = ""
		self.cellShape = "Hexagonal"
		self.rateType = "Average"
		self.weight1_asc = 0
		self.weight2_asc = 0
		self.index_lat_asc = 0 
		self.index_lon_asc = 0
		self.index_lat_dsc = 0
		self.index_lon_dsc = 0
		self.weight1_dsc = 0
		self.weight2_dsc = 0
		self.vel_dsc = 0
		self.vel_asc = 0
		self.cellSize = 50
		self.heading_Asc = -10
		self.heading_dsc = 190
		self.incidence_asc = -39
		self.incidence_dsc = 36
		self.start_date = 0
		self.end_date = 0
		self.resampling_interval = 7
		self.Displacements_dsc = 0
		self.Displacements_asc = 0
		self.is_checked_weight1 = True
		self.is_checked_weight2 = True
		self.only_plot = False
		if path:
			self.load(path)

	def dumpJson(self, file):
		with open (file, 'w') as wb:
			wb.write(json.dumps(self.__dict__, separators=(',\n', ': ')))

	def load(self, file):
		try:
			with open(file, 'r') as rb:
				paramJson = json.load(rb)
				for item, value in paramJson.items():
					if item in self.__dict__:
						self.__dict__[item] = value
		except:
			self.__init__()

class mainWindow(QtWidgets.QDialog, Ui_PSVectorialDecompositor):

	def __init__(self, parent):
		super(mainWindow, self).__init__(parent.mainWindow())
		self.setupUi(self)
		self.save_path = ""
		self.min_date_asc = ""
		self.min_date_dsc = ""
		self.max_date_asc = ""
		self.max_date_dsc = ""
		self.TimeASC= []
		self.TimeDSC= []
		self.iface = parent
		self.set_combobox()
		self.ComboDescendingLayer.setEnabled(False)
		self.SavePathText.setEnabled(False)
		self.SavePathButton.setEnabled(False)
		self.Weight1Check.setChecked(True)
		self.Weight2Check.setChecked(True)
		self.signals = Signals()
		self.ComboCellShape.addItems(["Hexagonal","Squared"])
		self.ComboInterpolationMethod.addItems(["Average", "Inverse Distance Weighting"])
		self.ComboUtmZone.addItems(["","N", "S"])
		self.ComboAscendingLayer.currentIndexChanged.connect(self.combo_layer_asc)
		self.ComboDescendingLayer.currentIndexChanged.connect(self.combo_layer_desc)
		self.SavePathButton.clicked.connect(self.save_window)
		
		self.loaderASC 	= AttributeLoaderASC()
		self.loaderDSC 	= AttributeLoaderDSC()
		self.rundecomp = RunDecomposition()
		# self.updater = updaterDialog(parent=self)
		self.updater = updaterDialog()
		self.loaderASC.signals.loaderASC.connect(self.setFeatAndValASC)
		self.loaderASC.signals.status.connect(self.updateUpdaterStatus)
		self.loaderASC.signals.progress.connect(self.updateUpdaterPbar)
		self.loaderDSC.signals.loaderDSC.connect(self.setFeatAndValDSC)
		self.loaderDSC.signals.status.connect(self.updateUpdaterStatus)
		self.loaderDSC.signals.progress.connect(self.updateUpdaterPbar)
		self.rundecomp.signals.done_decomp.connect(self.done_decomposition)
		self.rundecomp.signals.progress.connect(self.updateUpdaterPbar)
		self.rundecomp.signals.status.connect(self.updateUpdaterStatus)
		self.RunPVDButton.clicked.connect(self.performDecomposition)
		self.PlotButton.clicked.connect(self.plot_result)
		# if not os.path.exists(os.path.join(os.path.dirname(__file__),'.config')):
		# 	self.setInstallationPath(first = True)
		# self.actionSet_Installation_Path.triggered.connect(self.setInstallationPath)
		# with open(os.path.join(os.path.dirname(__file__),'.config'),'r') as f:
		# 	line = f.readline()
		# 	if 'bin_path' in line:
		# 		self.exe = line.split('=')[-1].strip()

	def updateUpdaterStatus(self, val):
		self.updater.label.setText(val)

	def updateUpdaterPbar(self, val):
		# self.updater.progressBar.setValue(val)
		if val >=0:
			self.updater.progressBar.setRange(0,100)
			self.updater.progressBar.setValue(val)
		elif val ==-1:
			self.updater.progressBar.setRange(0,0)

	# def setInstallationPath(self,first=False):
	# 	if first:
	# 		reply = QtWidgets.QMessageBox.question(self, 'Installation Path', 'Installation Path not set, Set it now?',
    #     	QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
	# 		if reply == QtWidgets.QMessageBox.Yes:
	# 			direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
	# 			if direct[0]:
	# 				config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 				config.write(f"bin_path = {direct[0]}")
	# 	else:
	# 		direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
	# 		if direct[0]:
	# 			config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 			config.write(f"bin_path = {direct[0]}")

	def setFeatAndValASC(self, signal):
		self.fieldsASC 	= self.loaderASC.fields
		self.valuesASC 	= self.loaderASC.attributes
		self.ComboLatitudeAscending.setEnabled(True)
		self.ComboLongitudeAscending.setEnabled(True)
		self.ComboHeightAscending.setEnabled(True)
		self.ComboVelocityAscending.setEnabled(True)
		self.ComboWheight1Ascending.setEnabled(True)
		self.ComboWeight2Ascending.setEnabled(True)
		lat = 0
		lon=0
		height = 0
		vel = 0
		coher = 0
		sigma_vel = 0
		min_temp = 0
		self.DisplacementsASC = 0
		for i,fld in enumerate(self.fieldsASC):
			if "LAT" == fld:
				lat = i
				self.index_latASC = i
			elif "LON" == fld:
				lon = i
				self.index_lonASC = i
			elif "HEIGHT" == fld:
				height = i
			elif "VEL" == fld:
				vel = i
			elif "COHER" == fld:
				coher = i
			elif "SIGMA VEL" == fld:
				sigma_vel = i
			elif QRegExp( "[0-9]{8}", Qt.CaseInsensitive ).indexIn( fld ) >= 0:
				# print(fld)
				fil = re.search("[0-9]{8}",fld).group()
				
				self.TimeASC.append(QDate.fromString( fil, "yyyyMMdd" ).toPyDate())
				if min_temp == 0:
					# print(i)
					self.DisplacementsASC = i
					self.min_date_asc = QDate.fromString( fil, "yyyyMMdd" ).toPyDate()
					min_temp +=1
				else:
					self.max_date_asc = QDate.fromString( fil, "yyyyMMdd" ).toPyDate()

		self.ComboLatitudeAscending.addItems(self.fieldsASC)
		self.ComboLongitudeAscending.addItems(self.fieldsASC)
		self.ComboHeightAscending.addItems(self.fieldsASC)
		self.ComboVelocityAscending.addItems(self.fieldsASC)
		self.ComboWheight1Ascending.addItems(self.fieldsASC)
		self.ComboWeight2Ascending.addItems(self.fieldsASC)
		self.ComboLatitudeAscending.setCurrentIndex(lat)
		self.ComboLongitudeAscending.setCurrentIndex(lon)
		self.ComboHeightAscending.setCurrentIndex(height)
		self.ComboVelocityAscending.setCurrentIndex(vel)
		self.ComboWheight1Ascending.setCurrentIndex(coher)
		self.ComboWeight2Ascending.setCurrentIndex(sigma_vel)
		self.ComboDescendingLayer.setEnabled(True)
		
		self.updater.close()
		
	
	def setFeatAndValDSC(self, signal):
		self.fieldsDSC 	= self.loaderDSC.fields
		self.valuesDSC 	= self.loaderDSC.attributes
		self.ComboLatitudeDescending.setEnabled(True)
		self.ComboLongitudeDescending.setEnabled(True)
		self.ComboHeightDescending.setEnabled(True)
		self.ComboVelocityDescending.setEnabled(True)
		self.ComboWheight1Descending.setEnabled(True)
		self.ComboWeight2Descending.setEnabled(True)
		lat = 0
		lon=0
		height = 0
		vel = 0
		coher = 0
		sigma_vel = 0
		min_temp=0
		self.DisplacementsDSC = 0
		for i,fld in enumerate(self.fieldsDSC):
			if "LAT" == fld:
				lat = i
				self.index_latDSC = i
			elif "LON" == fld:
				lon = i
				self.index_lonDSC = i
			elif "HEIGHT" == fld:
				height = i
			elif "VEL" == fld:
				vel = i
			elif "COHER" == fld:
				coher = i
			elif "SIGMA VEL" == fld:
				sigma_vel = i
			elif QRegExp( "[0-9]{8}", Qt.CaseInsensitive ).indexIn( fld ) >= 0:
				fil = re.search("[0-9]{8}",fld).group()
				self.TimeDSC.append(QDate.fromString( fil, "yyyyMMdd" ).toPyDate())
				if min_temp == 0:
					self.DisplacementsDSC = i
					self.min_date_dsc = QDate.fromString( fil, "yyyyMMdd" ).toPyDate()
					
					min_temp +=1
				else:
					self.max_date_dsc = QDate.fromString( fil, "yyyyMMdd" ).toPyDate()
			
		self.startDate = max(self.min_date_dsc,self.min_date_asc)
		self.endDate = min(self.max_date_dsc,self.max_date_asc) 
		self.StartDateValue.setDate(self.startDate)
		self.EndDateValue.setDate(self.endDate)
		self.ComboLatitudeDescending.addItems(self.fieldsDSC)
		self.ComboLongitudeDescending.addItems(self.fieldsDSC)
		self.ComboHeightDescending.addItems(self.fieldsDSC)
		self.ComboVelocityDescending.addItems(self.fieldsDSC)
		self.ComboWheight1Descending.addItems(self.fieldsDSC)
		self.ComboWeight2Descending.addItems(self.fieldsDSC)
		self.ComboLatitudeDescending.setCurrentIndex(lat)
		self.ComboLongitudeDescending.setCurrentIndex(lon)
		self.ComboHeightDescending.setCurrentIndex(height)
		self.ComboVelocityDescending.setCurrentIndex(vel)
		self.ComboWheight1Descending.setCurrentIndex(coher)
		self.ComboWeight2Descending.setCurrentIndex(sigma_vel)
		self.SavePathText.setEnabled(True)
		self.SavePathButton.setEnabled(True)
		
		self.updater.close()
	
	def save_window(self):
		direct = QtWidgets.QFileDialog.getExistingDirectory(self,"Save path ...")
		self.SavePathText.clear()
		self.save_path = direct
		self.SavePathText.insert(direct)
		if direct:
			self.RunPVDButton.setEnabled(True)
	
	def set_combobox(self):
		layers_names = []
		layers_names.append("")
		for layer in QgsProject.instance().mapLayers().values():
			layers_names.append(layer.name())
		self.ComboAscendingLayer.addItems(layers_names) 
		self.ComboDescendingLayer.addItems(layers_names)

	def combo_layer_asc(self):
		self.TimeASC= []
		asc = self.ComboAscendingLayer.currentText()
		layer = QgsProject.instance().mapLayersByName(asc)[0]
		self.loaderASC.setter(layer,self.NullValue.value())
		self.updater.label.setText('Reading Ascending attributes...')
		self.updater.show()
		self.updater.raise_()
		self.loaderASC.start()
		
	
	def combo_layer_desc(self):
		self.TimeDSC= []
		dsc = self.ComboDescendingLayer.currentText()
		layer = QgsProject.instance().mapLayersByName(dsc)[0]
		
		self.loaderDSC.setter(layer,self.NullValue.value())
		self.updater.label.setText('Reading Descending attributes...')
		self.updater.show()
		self.updater.raise_()
		#self.loader.setPriority(QThread.NormalPriority)
		self.loaderDSC.start()

	def closeEvent(self, event):
		self.updater.close()
	
	def performDecomposition(self):
		self.rundecomp.setter(self,self.signals)
		self.updater.label.setText('Resampling PSs time series...')
		self.updater.progressBar.setValue(0)
		self.updater.show()
		self.updater.raise_()
		ret = self.rundecomp.setParametersAndWriteFiles()
		if ret is None:
				QtWidgets.QMessageBox.warning(self, "Error", "Unable to read attributes")
				return
		self.rundecomp.start()

	def done_decomposition(self):
		print("done")
		self.updater.close()
		self.PlotButton.setEnabled(True)

	def plot_result(self):
		# for (dirpath, dirnames, filenames) in os.walk(self.save_path):
		for filenames in os.listdir(self.save_path):
			# print(filenames)
			if "grid_dec" in filenames:
				# print(filenames)
				if "EW" in filenames:
					path_EW = os.path.join(self.save_path,filenames)
				elif "UD" in filenames:
					path_UD = os.path.join(self.save_path,filenames)
				
		
		ValEW = pd.read_csv(path_EW)
		ValUD = pd.read_csv(path_UD)
		# print(ValEW.values[:,:2])
		NewCoord = ValEW.values[:,:2]
		# Vel = pd.read_csv(path_NewVel)
		# print(Vel.values)
		NewVel_EW = ValEW.values[:,2]
		NewVel_UD = ValUD.values[:,2]
		# print(ValEW.shape, Vel.shape)
		
		cm = plt.cm.get_cmap('viridis')
		sc = plt.scatter(NewCoord[:,0],NewCoord[:,1],s=15,c=NewVel_UD,cmap=cm)
		plt.colorbar(sc)
		plt.title("UP/DOWN")
		plt.xlabel('Longitude')
		plt.ylabel('Latitude')
		plt.grid()
		fig = plt.figure()
		cm2 = plt.cm.get_cmap('viridis')
		sc2 = plt.scatter(NewCoord[:,0],NewCoord[:,1],s=15,c=NewVel_EW,cmap=cm2)
		plt.colorbar(sc2)
		plt.title("EAST/WEST")
		plt.xlabel('Longitude')
		plt.ylabel('Latitude')
		plt.grid()
		plt.show()



class AttributeLoaderASC(QtCore.QThread):
	def __init__(self, parent = None):
		super(AttributeLoaderASC, self).__init__(parent)
		self.ps_layer	= None
		self.fields		= []
		self.attributes = []
		self.signals = Signals()
        
	def setter(self, ps_layer,null_value):
		self.fields		= []
		self.attributes = []
		self.null_value = null_value
		self.ps_layer 	= ps_layer
	
	def run(self):
		self.fields		= []
		self.attributes = []
		# print(self.null_value)
		fattr 	= []
		fid 	= []
		features = self.ps_layer.getFeatures()
		nFeat = len(self.ps_layer)
		i = 0
		for index in features:
			i+=1
			attr = []
			self.signals.progress.emit(100*i/nFeat)
			attributes =np.array(list(index.attributes()))#,dtype='float64')
			attributes[attributes==self.null_value] = np.nan
			attributes[attributes==NULL] = np.nan 
			attributes = attributes.astype("float64")
			attributes = np.around(attributes*1e6)/1e6
			attr = attributes
			fattr.append( attr )
			
			fid.append( fattr[0][0] )
		if fid is None:
			return

		infoFields = []	# hold the index->name of the fields containing info to be displayed

		ps_source 	= self.ps_layer.source()
		ps_fields 	= self.ps_layer.dataProvider().fields()
		providerType = self.ps_layer.providerType()

		for fld in ps_fields:
			infoFields.append(fld.name())
		self.fields 	= infoFields
		self.attributes = fattr
		self.signals.loaderASC.emit(0)

class AttributeLoaderDSC(QtCore.QThread):
	def __init__(self, parent = None):
		super(AttributeLoaderDSC, self).__init__(parent)
		self.ps_layer	= None
		self.fields		= []
		self.attributes = []
		self.signals = Signals()
        
	def setter(self, ps_layer,null_value):
		self.fields		= []
		self.attributes = []
		self.null_value = null_value
		self.ps_layer 	= ps_layer
	
	def run(self):
		self.fields		= []
		self.attributes = []
		fattr 	= []
		fid 	= []
		features = self.ps_layer.getFeatures()
		nFeat = len(self.ps_layer)
		i = 0
		
		for index in features:
			i+=1
			attr = []
			self.signals.progress.emit(100*i/nFeat)
			attributes =np.array(list(index.attributes()))#,dtype='float64')
			attributes[attributes==self.null_value] = np.nan
			attributes[attributes==NULL] = np.nan 
			attributes = attributes.astype("float64")
			attributes = np.around(attributes*1e6)/1e6
			
			
			attr = attributes
			fattr.append( attr )
			fid.append( fattr[0][0] )
		if fid is None:
			return

		infoFields = []	# hold the index->name of the fields containing info to be displayed

		ps_source 	= self.ps_layer.source()
		ps_fields 	= self.ps_layer.dataProvider().fields()
		providerType = self.ps_layer.providerType()

		for fld in ps_fields:
			infoFields.append(fld.name())

		self.fields 	= infoFields
		self.attributes = fattr
		self.signals.loaderDSC.emit(0)

class RunDecomposition(QtCore.QThread):

	def __init__(self, parent = None):
		super(RunDecomposition, self).__init__(parent)
		self.signals = Signals()
		self.exe  = None
		self.parametersPath = None 
		self.parent = parent
	
	def setter(self,main,signals):
		self.main = main

	def run(self):
		
		args=[self.exe, '-p','decomp', '-f', self.parametersPath ]
		print(args)
		if sys.platform.startswith('win'):
			proc = subprocess.Popen(args, shell=True)
			self.signals.status.emit("Performing Vectorial Decomposition")
			self.signals.progress.emit(-1)
			proc.wait()
		else:
			proc = subprocess.Popen(args, shell=False)
			self.signals.status.emit("Performing Vectorial Decomposition")
			self.signals.progress.emit(-1)
			proc.wait()
		print("RUN")
		self.signals.done_decomp.emit(0)

	def setParametersAndWriteFiles(self):
		if os.path.exists(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config')):
			with open(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config'),'r') as f:
				line = f.readline()
				if 'bin_path' in line:
					self.exe = line.split('=')[-1].strip()

			parameters = Parameters()
			parameters.save_path = self.main.save_path
			parameters.cellShape = self.main.ComboCellShape.currentText()
			parameters.rateType = self.main.ComboInterpolationMethod.currentText()
			parameters.weight1_asc = self.main.ComboWheight1Ascending.currentIndex()
			parameters.weight2_asc = self.main.ComboWeight2Ascending.currentIndex()
			parameters.index_lat_asc = self.main.index_latASC
			parameters.index_lon_asc = self.main.index_lonASC
			parameters.index_lat_dsc = self.main.index_latDSC
			parameters.index_lon_dsc = self.main.index_lonDSC
			parameters.weight1_dsc = self.main.ComboWheight1Descending.currentIndex()
			parameters.weight2_dsc = self.main.ComboWeight2Descending.currentIndex()
			parameters.vel_dsc = self.main.ComboVelocityDescending.currentIndex()
			parameters.vel_asc = self.main.ComboVelocityAscending.currentIndex()
			parameters.cellSize = self.main.CellSizeValue.value()
			parameters.heading_Asc = self.main.OrbitHeadingAscending.value()
			parameters.heading_dsc = self.main.OrbitHeadingDescending.value()
			parameters.incidence_asc = self.main.OrbitIncidenceAscending.value()
			parameters.incidence_dsc = self.main.OrbitIncidenceDescending.value()
			parameters.start_date = str(self.main.startDate)
			parameters.end_date = str(self.main.endDate)
			parameters.resampling_interval = self.main.ResamplingIntervalValue.value()
			parameters.Displacements_dsc = self.main.DisplacementsDSC
			parameters.Displacements_asc = self.main.DisplacementsASC
			parameters.is_checked_weight1 = self.main.Weight1Check.isChecked()
			parameters.is_checked_weight2 = self.main.Weight2Check.isChecked()
			self.parametersPath = os.path.join(parameters.save_path, 'parameters.json')
			values_asc_txt = os.path.join(self.main.save_path,"values_asc.csv")
			values_dsc_txt = os.path.join(self.main.save_path,"values_dsc.csv")
			time_asc_txt = os.path.join(self.main.save_path,"time_asc.csv")
			time_dsc_txt = os.path.join(self.main.save_path,"time_dsc.csv")
			parameters.values_asc_file = values_asc_txt
			parameters.values_dsc_file = values_dsc_txt
			parameters.time_asc_file = time_asc_txt
			parameters.time_dsc_file = time_dsc_txt

			parameters.dumpJson(self.parametersPath)
			# print(np.array(self.main.TimeASC).shape, np.array(self.main.valuesASC).shape, np.array(self.main.valuesASC)[:,self.main.DisplacementsASC:].shape)

			values_asc = self.main.valuesASC
			values_dsc = self.main.valuesDSC
			time_asc = self.main.TimeASC
			time_dsc = self.main.TimeDSC
			df_values_asc = pd.DataFrame(values_asc)
			df_values_dsc = pd.DataFrame(values_dsc)
			df_time_asc = pd.DataFrame(time_asc)
			df_time_dsc = pd.DataFrame(time_dsc)
			csv_val_asc = parameters.values_asc_file
			df_values_asc.to_csv(csv_val_asc)
			csv_val_dsc = parameters.values_dsc_file
			df_values_dsc.to_csv(csv_val_dsc)
			csv_time_asc = parameters.time_asc_file
			df_time_asc.to_csv(csv_time_asc)
			csv_time_dsc = parameters.time_dsc_file
			df_time_dsc.to_csv(csv_time_dsc)
		else:
			QtWidgets.QMessageBox.warning(self.main, "No Installation Path", "No Installation Path Selected, go to Settings and set it.")
		return 0

class updaterDialog(QtWidgets.QMainWindow, Ui_ProgressMainWindow):
    def __init__(self, parent=None, text = "Dowload in progress... "):
        super(updaterDialog, self).__init__(parent)
        self.setupUi(self)
        self.label.setText(text)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.parent         = parent
        self.progressBar    = QtWidgets.QProgressBar(self.centralwidget)
        self.progressBar.setMaximumSize(QtCore.QSize(16777215, 15))
        self.progressBar.setProperty("value", 0)
        self.progressBar.setObjectName("progressBar")
        self.gridLayout.addWidget(self.progressBar, 1, 0, 1, 1)
   
    def updateProgressBar(self, val):
        self.progressBar.setValue(val)

    def updateStatus(self, status):  
        self.label.setText(status)
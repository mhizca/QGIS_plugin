from ..ui.Progress_ui import  Ui_ProgressMainWindow
from .ui.HeatMap_ui import Ui_Heatmap
from PyQt5 import QtCore, QtGui, QtWidgets
from qgis.core import QgsProject, QgsMapLayer, QgsWkbTypes
from qgis.core import QgsProject,NULL, QgsRasterLayer
from qgis.PyQt.QtCore import Qt, QRegExp, QDate, QFileInfo, QDir
# from .core import Export
import matplotlib.pyplot as plt
import re
import numpy as np
import os
import json
import pandas as pd
import sys
import subprocess

class Signals(QtCore.QObject):
	done = QtCore.pyqtSignal(int)
	status = QtCore.pyqtSignal(str)
	progress = QtCore.pyqtSignal(float)
	doneloader = QtCore.pyqtSignal(int)

class Parameters(object):
    
	def __init__(self, path = None):

		self.radius = 100.0
		self.pixel_size_x = 0.1
		self.pixel_size_y = 0.1
		self.var_radius = 50
		self.open_file = True
		self.threshold = ""
		self.weight_from_field = ""
		self.weight2_from_field = ""
		self.kernel_shape = "Hexagonal"
		self.units = "Meters"
		self.PSfile = ""
		self.location = ""
		self.save_path = ""
		self.vector_layer = ""
		if path:
			self.load(path)

	def dumpJson(self, file):
		with open (file, 'w') as wb:
			wb.write(json.dumps(self.__dict__, separators=(',\n', ': ')))

	def load(self, file):
		try:
			with open(file, 'r') as rb:
				paramJson = json.load(rb)
				for item, value in paramJson.items():
					if item in self.__dict__:
						self.__dict__[item] = value
		except:
			self.__init__()
	
class mainWindow(QtWidgets.QDialog, Ui_Heatmap):

	def __init__(self,  parent):
		super(mainWindow, self).__init__(parent.mainWindow())
		self.setupUi(self)
		self.set_combobox()
		self.signals = Signals()
		self.parent = parent
		self.Kernel_Shape_Combo.addItems(["Hexagonal","Squared"])
		self.Point_layer_combo.currentIndexChanged.connect(self.combo_layer1)
		self.SavePathButton.clicked.connect(self.save_window)
		self.Run_Button.clicked.connect(self.export_heatmap)
		self.loader 	= AttributeLoader()
		self.updater = updaterDialog()
		self.runexport = RunHeatMap()
		self.loader.signals.doneloader.connect(self.setFeatAndVal)
		self.loader.signals.status.connect(self.updateUpdaterStatus)
		self.loader.signals.progress.connect(self.updateUpdaterPbar)
		self.runexport.signals.done.connect(self.export_done)
		self.runexport.signals.status.connect(self.updateUpdaterStatus)
		self.runexport.signals.progress.connect(self.updateUpdaterPbar)
		self.Pixel_Size_y.valueChanged.connect(self.valuechange_Y)
		self.Pixel_Size_x.valueChanged.connect(self.valuechange_X)
		self.threshold_check.toggled.connect(self.thresh_changed)
		# print(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config'))
		# if not os.path.exists(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config')):
		# 	self.setInstallationPath(first = True)
		# self.actionSet_Installation_Path.triggered.connect(self.setInstallationPath)
		

	def updateUpdaterStatus(self, val):
		self.updater.label.setText(val)

	def updateUpdaterPbar(self, val):
		if val >=0:
			self.updater.progressBar.setRange(0,100)
			self.updater.progressBar.setValue(val)
		elif val ==-1:
			self.updater.progressBar.setRange(0,0)

	def thresh_changed(self):
		if self.threshold_check.isChecked():
			self.threshold_value.setEnabled(True)
		else:
			self.threshold_value.setEnabled(False)
			self.threshold_value.setValue(0)
			


	# def setInstallationPath(self,first=False):
	# 	if first:
	# 		reply = QtWidgets.QMessageBox.question(self, 'Installation Path', 'Installation Path not set, Set it now?',
    #     	QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
	# 		if reply == QtWidgets.QMessageBox.Yes:
	# 			direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
	# 			if direct[0]:
	# 				config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 				config.write(f"bin_path = {direct[0]}")
	# 	else:
	# 		direct = QtWidgets.QFileDialog.getOpenFileName(self,"Select Installation File")
	# 		if direct[0]:
	# 			config = open(os.path.join(os.path.dirname(__file__),'.config'),"w")
	# 			config.write(f"bin_path = {direct[0]}")

	def valuechange_X(self):
		self.Pixel_Size_y.setValue(self.Pixel_Size_x.value())

	def valuechange_Y(self):
		self.Pixel_Size_x.setValue(self.Pixel_Size_y.value())
		

	
	def combo_layer1(self):
		self.TimeASC= []
		asc = self.Point_layer_combo.currentText()
		layer = QgsProject.instance().mapLayersByName(asc)[0]
		# self.layer = layer
		self.width = layer.extent().width()
		self.height = layer.extent().height()
		# print(dir(layer.crs()))
		self.layer = layer.dataProvider().dataSourceUri()
		self.units = layer.crs().mapUnits()
		print(self.units)
		# print(QgsUnitTypes.toString(units))
		# print(layer.crs().mapUnits())
		# self.Rows_Value.setValue(np.ceil((self.height+2*self.Radius_Value.value())/self.Pixel_Size_x.value()))
		# self.Cols_Value.setValue(np.ceil((self.width+2*self.Radius_Value.value())/self.Pixel_Size_x.value()))
		if self.units != 0 :
			self.units = "Meters"
			# self.Rows_Value.clear()
			# self.Rows_Value.setEnabled(False)
			# self.Cols_Value.clear()
			# self.Cols_Value.setEnabled(False)
		else:
			self.units = "Degree"
			# self.Rows_Value.setEnabled(True)
			# self.Cols_Value.setEnabled(True)
		self.loader.setter(layer)
		self.updater.label.setText('Reading Layer attributes...')
		self.updater.show()
		self.updater.raise_()
		self.loader.start()
	
	def export_done(self):
		print("Done!!")
		self.updater.close()
		if self.Open_Output_Check.isChecked():
			rlayer = QgsRasterLayer(self.save_path, "SRTM layer name")
			if not rlayer.isValid():
				print("Layer failed to load!")
			else:
				# print(self.threshold_check.isChecked())
				if self.threshold_check.isChecked():
					self.parent.addRasterLayer(self.save_path,f"Heatmap_threshold_{self.threshold_value.value()}")
				else:
					self.parent.addRasterLayer(self.save_path,"Heatmap")

	def set_field_combos(self):
		fields = []
		fields.append("")
		for field in self.fields:
			fields.append(field)
		self.Weight_from_Field_Combo.addItems(fields)
		self.Weight2_from_Field_Combo.addItems(fields)

	def setFeatAndVal(self, signal):
		self.fields 	= self.loader.fields
		self.values 	= self.loader.attributes
		self.location   = self.loader.location
		self.set_field_combos()
		self.updater.close()

	def export_heatmap(self):
		self.updater.label.setText('Exporting heatmap...')
		self.updater.progressBar.setValue(0)
		self.updater.show()
		self.updater.raise_()
		self.weight_from_field_index = self.Weight_from_Field_Combo.currentIndex()
		self.weight2_from_field_index = self.Weight2_from_Field_Combo.currentIndex()
		self.runexport.setParametersAndWriteFiles(self)#,self.signals)
		self.runexport.start()


	def closeEvent(self, event):
		self.updater.close()
	
	
	def save_window(self):
		direct = QtWidgets.QFileDialog.getSaveFileName(self, "Save Path", filter='TIF files (*.tif)')
		if direct[0][-4:] != ".tif":
			dire = direct[0] + ".tif"
		else:
			dire = direct[0]
		self.SavePathText.clear()
		self.save_path = dire
		self.SavePathText.insert(dire)
	
	def set_combobox(self):
		layers_names = []
		layers_names.append("")
		for layer in QgsProject.instance().mapLayers().values():
			layers_names.append(layer.name())
		self.Point_layer_combo.addItems(layers_names) 
		

class AttributeLoader(QtCore.QThread):
	def __init__(self, parent = None):
		super(AttributeLoader, self).__init__(parent)
		self.ps_layer	= None
		self.fields		= []
		self.attributes = []
		self.signals = Signals()
        
	def setter(self, ps_layer):
		self.fields		= []
		self.attributes = []
		self.ps_layer 	= ps_layer
	
	def run(self):
		self.fields		= []
		self.attributes = []
		fattr 	= []
		fid 	= []
		features = self.ps_layer.getFeatures()
		nFeat = len(self.ps_layer)
		i = 0
		location = []
		for index in features:
			i+=1
			attr = []
			self.signals.progress.emit(100*i/nFeat)
			attributes = np.around(np.array(list(index.attributes()))*1e6)/1e6
			attributes[attributes==NULL] = np.nan
			attr = attributes
			location.append((index.geometry().asPoint()[0],index.geometry().asPoint()[1]))
			# print(index.geometry().asPoint()[0],index.geometry().asPoint()[1])
			fattr.append( attr )
			
			fid.append( fattr[0][0] )
		if fid is None:
			return

		infoFields = []	# hold the index->name of the fields containing info to be displayed

		ps_source 	= self.ps_layer.source()
		ps_fields 	= self.ps_layer.dataProvider().fields()
		providerType = self.ps_layer.providerType()

		for fld in ps_fields:
			infoFields.append(fld.name())
		
		self.fields 	= infoFields
		self.attributes = fattr
		# print(location)
		self.location = location
		self.signals.doneloader.emit(0)

class RunHeatMap(QtCore.QThread):
	
	def __init__(self, parent = None):
		super(RunHeatMap, self).__init__(parent)
		self.signals = Signals()
	
	def run(self):
		
		args=[self.exe, '-p','heatmap', '-f', self.parametersPath ]
		self.signals.status.emit("Processing HeatMap...")
		self.signals.progress.emit(-1)
		print(args)
		if sys.platform.startswith('win'):
			proc = subprocess.Popen(args, shell=True)
			proc.wait()
		else:
			proc = subprocess.Popen(args, shell=False)
			proc.wait()
		print("RUN")
		self.signals.done.emit(0)

	def setParametersAndWriteFiles(self,main):
		if os.path.exists(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config')):
			with open(os.path.join(os.path.dirname(os.path.dirname(__file__)),'.config'),'r') as f:
				line = f.readline()
				if 'bin_path' in line:
					self.exe = line.split('=')[-1].strip()

			parameters = Parameters()
			pn,fn =  os.path.split(main.save_path)
			parameters.save_path = main.save_path
			parameters.radius = main.Radius_Value.value()
			# parameters.rows = main.Rows_Value.value()
			# parameters.cols = main.Cols_Value.value()
			parameters.pixel_size_x = main.Pixel_Size_x.value()
			parameters.pixel_size_y = main.Pixel_Size_y.value()
			parameters.var_radius = main.Var_Rad_Value.value()
			parameters.open_file = main.Open_Output_Check.isChecked()
			if main.threshold_check.isChecked():
				parameters.threshold = main.threshold_value.value()
			parameters.units = main.units
			parameters.weight_from_field = main.weight_from_field_index
			parameters.weight2_from_field = main.weight2_from_field_index
			parameters.kernel_shape = main.Kernel_Shape_Combo.currentText()
			parameters.vector_layer = main.layer
			# print(main.layer)
			ps_path = os.path.join(pn,"Data.csv")
			parameters.PSfile = ps_path
			location_path = os.path.join(pn,"locations.csv")
			parameters.location = location_path
			table = []
			for index in main.values:
				attribute = index
				table.append(list(attribute))
				# print(attribute)
			infoFields = []
			for field in main.fields:
				infoFields.append(field)
			df = pd.DataFrame(table,  columns = infoFields)
			csv_doc = parameters.PSfile
			df.to_csv(csv_doc)
			df_loc = pd.DataFrame(main.location)
			# print(df_loc)
			csv_doc_loc = parameters.location
			df_loc.to_csv(csv_doc_loc)

			self.parametersPath = os.path.join(pn, 'parameters.json')
			parameters.dumpJson(self.parametersPath)
		else:
			QtWidgets.QMessageBox.warning(main, "No Installation Path", "No Installation Path Selected, go to Settings and set it.")
		return 0


class updaterDialog(QtWidgets.QMainWindow, Ui_ProgressMainWindow):
    def __init__(self, parent=None, text = "Dowload in progress... "):
        super(updaterDialog, self).__init__(parent)
        self.setupUi(self)
        self.label.setText(text)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.parent         = parent
        self.progressBar    = QtWidgets.QProgressBar(self.centralwidget)
        self.progressBar.setMaximumSize(QtCore.QSize(16777215, 15))
        self.progressBar.setProperty("value", 0)
        self.progressBar.setObjectName("progressBar")
        self.gridLayout.addWidget(self.progressBar, 1, 0, 1, 1)
   
    def updateProgressBar(self, val):
        self.progressBar.setValue(val)

    def updateStatus(self, status):  
        self.label.setText(status)
        